/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

/**
 *
 * @author saad
 */
public class ServerStart {
    
    public static void main( String [] args )
    {
        System.out.println("YO YO");
        new LogInChecker() ;
        new OOPChecker() ;
        new DLDChecker() ;
        new DSChecker() ;
        new DMChecker() ;
        new NotificationChecker() ;
        new InfoChecker() ;
        
          
    }
    
}
